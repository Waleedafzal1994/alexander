

<?php $__env->startSection('content'); ?>
<div class="container-fluid admin-container">
    <h6>Admin Panel - Users </h6>
    <small><?php echo e(date('Y-m-d H:i:s')); ?></small>
    <p>Below you may find a list of all the users, search for a specific user and editing their info.</p>
    <br>
    <hr>
    <br>
    <label for="">Search for an User (Name, Email)</label>
    <input type="search" id="searchInput" id="">
    <br>
    <br>



            <div class="table-responsive">
            <table class="table table-striped" style="text-align: center">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Last Login</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="usersTbl">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->country); ?></td>
                        <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                        <td><a href="/admin/users/<?php echo e($user->id); ?>" class="btn btn-primary">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
            <?php echo e($users->links()); ?>



</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var usersOld = $('#usersTbl').html();

        function debounce(func, timeout = 500){
            let timer;
            return (...args) => {
              clearTimeout(timer);
              timer = setTimeout(() => { func.apply(this, args); }, timeout);
            };
          }

        const searchForUser = debounce(() => searchUser());


        function searchUser(query) {
            var query = $('#searchInput').val();
            if(query.length > 3) {
                $.ajax({
                    type: "GET",
                    url: "/admin/usersSearch/",
                    data: {q: query},
                    success: function (response) {
                        var users = JSON.parse(response);
                        var html = '';
                        console.log(typeof users);
                        if(typeof users == 'object' && users.length > 0) {
                            users.forEach(user => {
                                html += '<tr><td>'+user['name']+'</td><td></td><td></td><td><a href="/admin/users/'+user['id']+'" class="btn btn-primary">Edit</a></td></tr>';
                            });
                            $('#usersTbl').html(html);
                        } else {
                            $('#usersTbl').html('<td colspan="4">No results.</td>');
                        } 
                    }
                });
            } else {
                $('#usersTbl').html(usersOld);
            }
        }

        $('#searchInput').keydown(function (e) { 
            searchForUser();
        });

    
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/admin/users.blade.php ENDPATH**/ ?>