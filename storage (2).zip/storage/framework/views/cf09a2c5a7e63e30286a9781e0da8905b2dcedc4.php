<li class="nav-item active" id="<?php echo e(!empty($service->category->id) ? $service->category->id : ''); ?>" value="<?php echo e(!empty($service->category->id) ? $service->category->id : ''); ?>" onclick="getCategoryServices(this,this.id)">
    <?php if($service->category->image_1 != null): ?>



    <div class="categories_box_holder" style="background-image:linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3)),url('<?php echo e(url($service->category->image_1)); ?>');">
        <?php else: ?>
        <div class="categories_box_holder" style="background:var(--color-secondary);">
        </div>
    </div>
    <?php endif; ?>
    <p><?php echo e($service->category->name); ?></p>
</li>



<?php $i = 1;
$order_arr = array();
$order_arr[0] = $service->category->id; ?>
<?php if(!empty($all_remaining_cats)): ?>
<?php $__currentLoopData = $all_remaining_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



<?php array_push($order_arr, $category->id); ?>



<li class="nav-item" id="<?php echo e($category->id); ?>" onclick="getCategoryServices(this,this.id)" role="presentation" value="<?php echo e($category->id); ?>">
    <!-- IF STAART HERE -->
    <?php if($category->image_1 != null): ?>
    <div class="categories_box_holder" style="background-image:linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3)),url(<?php echo e(url($category->image_1)); ?>);">



    </div>
    <?php else: ?>
    <div class="categories_box_holder" style="background:var(--color-secondary);">
    </div>
    <?php endif; ?>



    <!-- ENd Here -->
    <p><?php echo e($category->name); ?></p>
</li>



<?php if($i >= 4): ?>
<?php break; ?>



<?php endif; ?>
<?php $i++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<input type="hidden" name="" id="cat_ord_arr" value="<?= !empty($order_arr) ? implode(',', $order_arr) : ''; ?>">

<?php endif; ?>

<?php if(!empty($all_remaining_cats) && (count($all_remaining_cats) >=4)): ?>

<li class="nav-item" role="presentation" id="<?php echo e($category->id); ?>" onclick="getCategoryServices(this,'more')">
    <!-- IF STAART HERE -->
    <!-- <div class="nav-link p-0" id="more_section"> -->
    <a class="nav-link p-0" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">
        <div class="categories_box_holder" style="background-image:linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3))">
            <!-- Else Section -->
            <!-- <div class="categories_box_holder" style="background:var(--color-secondary);">
                            </div> -->
            <!-- Else Section ENd Here -->
        </div>
        <!-- ENd Here -->
        <p>More</p>
    </a>
    <!-- </div> -->
</li>
<?php endif; ?><?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/services/categories-list.blade.php ENDPATH**/ ?>