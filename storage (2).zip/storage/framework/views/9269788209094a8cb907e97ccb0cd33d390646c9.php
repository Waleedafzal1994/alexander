

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="display:flex; justify-content:center; align-items:center;">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card" style="width:25rem; border-radius:10px 10px 0 0; margin-top:70px; border:0px;">
                <div class="header-page rounded-top">
                    <div>
                        <h4>Login</h4>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>


                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="alert alert-danger" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="alert alert-danger" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p class="card-text">Email</p>
                    <input id="email" type="email" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                        value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <br>
                    <br>
                    <p class="card-text">Password</p>
                    <input id="password" type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                        required autocomplete="current-password">

                    <br>
                    <br>
                    <div style="display:flex; align-items:center;">
                        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>

                            style="width:initial; margin-right:10px; ">
                        <p class="card-text">Remember me? </p>

                    </div>

                    <div style="padding-top:30px; text-align:center;">


                        <button class="btn button-primary" style="padding:5px 20px; widtH:100%;">Login</button>
                        <br>
                        <br>
                        <div style="margin:5px 0;">
                            <small>or login with</small>
                        </div>


                        <div class="row" style="justify-content: center">
                            <a href="/auth/discord"><img src="<?php echo e(asset('imgs/auth/discord.jpg')); ?>" alt=""
                                    style="height:28px;"></a>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>







    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/auth/login.blade.php ENDPATH**/ ?>