
<?php $__env->startSection('content'); ?>
<div class="header-page rounded">
    <div>
        <img src="/imgs/icons/news.png" alt="" srcset="" style="height:64px;">
    </div>
 
    <div>
        <h1>News</h1>
        <p>Here you may find the latest news and posts from the GamersPlay community.</p>
    </div>
</div>
    <div class="container-fluid">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>

        <div class="news-article">
            <div class="row">
                <div class="col-md-3">
                    <a href="/news/<?php echo e($post->id); ?>">
                        <div class="news-article-image" style="background:url('<?php echo e($post->image); ?>'); width:100%; height:150px; background-position:center; background-size:cover; border-radius:16px;"></div>
                    </a>
                </div>
                <div class="col-md-9">
                    <h4 style="margin:0; padding:0;"><a href="/news/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h4>
                    <?php if($post->postAuthor != null): ?>
                    <p style="padding-bottom:10px; border-bottom:1px solid var(--color-secondary);">by <span style="font-weight:bold;"><?php echo e($post->postAuthor->name); ?></span></p>
                    <?php endif; ?>
                   
                    <?php echo substr(strip_tags($post->content,'<br>'),0,150); ?>...
                    
                </div>
            </div>
           
        
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/news.blade.php ENDPATH**/ ?>