<div class="card mt-2 p-0">
    <div class="card-body">
        <div class="service-main-body-content">
            <div class="row">
                <div class="col-sm-12">
                
                <?php if(!empty($followingList)): ?>
                    <?php $__currentLoopData = $followingList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post-box">
                            <div class="central-meta item post-item-box" style="display: inline-block;" id="post-item-box-1">
                                <div class="user-post">
                                    <div class="friend-info">

                                    
                                                <figure>
                                                    <img src="<?php echo e($row->profile_picture); ?>" alt="">
                                                </figure>
                                                <div class="friend-name">
                                                
                                                    <ins>
                                                        <a href="javascript:void(0);" title=""><?php echo e($row->name); ?></a>
                                                    </ins>
                                                </div>
                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                <?php endif; ?>   
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/services/following.blade.php ENDPATH**/ ?>