<style type="text/css">
    .show-less{
        display: none !important;
    }
    .show-less-block{
        display: block !important;
    }
</style>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!empty($post)): ?>
<div class="central-meta item shadow remove-when-timeline-clicked" style="display: inline-block;" id="post-item-box-<?php echo e($post->id); ?>">
    <div class="user-post">
        <div class="friend-info">
            <div class="d-flex">
                <img src="<?php echo e($post->postAuthor->getProfilePicture()); ?>" style="height:80px;" width="80" class="rounded-circle mr-3" alt="">
                <div class="d-flex align-items-center justify-content-between w-100">
                    <div class="d-flex align-items-center w-100">
                        <div class="d-flex flex-column w-100">
                            <div class="d-flex align-items-center justify-content-between mt-3">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 font-weight-bold review-profile-heading"><a href="javascrip:void(0);" title=""><?php echo e(Str::upper($post->postAuthor->name ?: 'NA')); ?></a>
                                        
                                    </span>
                                    <span class="text-black">
                                        <!-- <i class="fa fa-globe"></i> -->
                                        <?php echo e($post->formatted_created_at); ?>

                                    </span>
                                </div>
                                <?php if($post->user_id == Auth::user()->id): ?>
                                <div class="more">
                                    <div class="more-post-optns post-actions" data-post="<?php echo e($post->id); ?>">
                                        <i class="fas fa-ellipsis-h"></i>
                                        <ul>
                                            
                                            <li class="delete-post-action"><i class="fas fa-trash"></i>Delete
                                                Post
                                            </li>
                                            
                                            
                                        </ul>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- New Design -->
                            <!-- <div id="carousel-1" class="lightbox mt-4 mb-5 carousel slide" data-ride="carousel" data-interval="false">
                                <ol class="carousel-indicators">
                                    <li data-target="#carousel-1" data-slide-to="0" class="active"></li>
                                    <li data-target="#carousel-1" data-slide-to="1"></li>
                                    <li data-target="#carousel-1" data-slide-to="2"></li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src="/imgs/services/astronaut.png" class="d-block w-100" alt="...">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="/imgs/services/astronaut.png" class="d-block w-100" alt="...">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="/imgs/services/astronaut.png" class="d-block w-100" alt="...">
                                    </div>
                                </div>
                                <a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev">
                                    <i class="fa-solid fa-location-arrow prev-icon"></i>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#carousel-1" role="button" data-slide="next">
                                    <i class="fa-solid fa-location-arrow next-icon"></i>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div> -->

                            <!-- New Design -->

                            <!-- This section is for pictures & comment-section and also dynamic -->
                            <div class="post-meta mt-3">
                                <div class="description">
                                    <!-- <p class="text-black"><?php echo $post->content; ?></p> -->
                                </div>
                                <div class="row">
                                    <p> <?php echo $post->videoContentHtml(); ?>

                                    </p>
                                </div>
                                <div class="carousel-row">
                                    <?php $images = $post->imageContentHtml() ?>
                                    <?php if(!empty($images) && $images->count()>0): ?>
                                     <div id="carousel-<?php echo e($post->id); ?>" class="lightbox mt-4 mb-5 post-carousel carousel slide" data-ride="carousel" data-interval="false">
                                        <ol class="carousel-indicators">
                                            <?php if(!empty($images)): ?>
                                                <?php $i=0; ?>
                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li data-target="#carousel-<?php echo e($post->id); ?>" data-slide-to="<?php echo e($i); ?>" class="<?php echo e($i == 0 ? 'active' :''); ?>"></li>
                                                    <?php $i++ ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            
                                        </ol>
                                        <div class="carousel-inner">

                                            <?php if(!empty($images)): ?>
                                                <?php $i=0; ?>
                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                                    <div class="carousel-item carousel-item-<?php echo e($post->id); ?> <?php echo e($i == 0 ? 'active' :''); ?>">
                                                        <img src="<?php echo e($value->file_name); ?>" class="d-block w-100" alt="...">
                                                    </div>
                                                        <?php $i++ ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            
                                        </div>
                                        <a class="carousel-control-prev" href="#carousel-<?php echo e($post->id); ?>" role="button" data-slide="prev">
                                            <i class="fa-solid fa-location-arrow prev-icon"></i>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                        
                                        <?php if(!empty($images) && count($images) > 1   ): ?>
                                        <a class="carousel-control-next" href="#carousel-<?php echo e($post->id); ?>" role="button" data-slide="next">
                                            <i class="fa-solid fa-location-arrow next-icon"></i>
                                            <span class="sr-only">Next</span>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                   
                                </div>
                                <div class="we-video-info">
                                    <ul>
                                        
                                        <li>
                                            <div class="likes heart post-reaction <?php echo e($post->userliked() ? 'active-heart' : ''); ?>" title="Like/Dislike" data-post-id="<?php echo e($post->id); ?>" data-reaction-id="<?php echo e($post->likedPost()); ?>">
                                                <i class="fas fa-heart"></i>
                                                <span class="liked_post_count"><?php echo e(shortNumber($post->likes_count)); ?></span>
                                            </div>
                                        </li>
                                        <li>
                                            <span class="comment" title="Comments">
                                                <i class="fa fa-commenting" ></i>
                                                <ins id="comment_post_count_<?php echo e($post->id); ?>"><?php echo e(shortNumber($post->comments_count)); ?></ins>
                                            </span>
                                        </li>

                                        
                                    </ul>
                                    <div class="users-thumb-list" id="people-liked-post-<?php echo e($post->id); ?>">
                                        <?php echo $post->postLikedUserNames(); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="coment-area ">
                                <ul class="we-comet" id="comment-box_<?php echo e($post->id); ?>">
                                    <?php echo $post->commentByUsers(); ?>

                                    
                                    <span id="append_comment_<?php echo e($post->id); ?>"></span>
                                    
                                    <div class="comment-loader" id="append_less_comment_<?php echo e($post->id); ?>" style="display: none;">
                                        <img src="<?php echo e(asset('imgs/loader.gif')); ?>">
                                    </div>


                                    <?php if($post->comments_count > 3): ?>
                                    <li>
                                        <a href="#" title="" class="showmore text-decoration-none" data-comment-load_page="1" data-comment-post-id="<?php echo e($post->id); ?>" id="showmore_<?php echo e($post->id); ?>">more comments+
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                    <li class="show-less show-less-<?php echo e($post->id); ?>">
                                        <a href="#" title="" class="showmore underline" data-comment-load_page="0" data-comment-post-id="<?php echo e($post->id); ?>" id="showless_<?php echo e($post->id); ?>">less comments-
                                        </a>
                                    </li>

                                    <li class="post-comment" id="post-comment_form_<?php echo e($post->id); ?>">
                                        <div class="d-flex">
                                            <div class="comet-avatar">
                                                <img width="80" src="<?php echo e(Auth::user()->getProfilePicture()); ?>" alt="">
                                            </div>
                                            <div class="post-comt-box">
                                                <form method="POST" action="#" id="comment_<?php echo e($post->id); ?>" data-post-id="<?php echo e($post->id); ?>">
                                                    
                                                    <input name="commentable_id" type="hidden" value="<?php echo e($post->id); ?>" id="commentable_id_<?php echo e($post->id); ?>">
                                                    <textarea name="body" rows="8" id="commentable_content_<?php echo e($post->id); ?>" data-post-id="<?php echo e($post->id); ?>" placeholder="Write a Comment"></textarea>

                                                    <!-- <button class="btn btn-primary"  type="buton">Post</button> -->
                                                    <input type="submit" class="btn btn-primary mt-2" name="" value="Post Comment">

                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- more post data -->
<div class="loader" style="display: none;">
    <img src="/imgs/loader.gif">
</div>
<div class="post-item-box"></div>

<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"/>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script> -->
<script>
$(document).ready(function(){
    //show comment//
    $('.comment').off().on('click', function(e) {
        e.stopImmediatePropagation();
            $(this).parents(".post-meta").siblings(".coment-area").slideToggle("slow");
        });
  // When strating hide prev arrow
  $('.carousel-control-prev').hide();


    jQuery(".post-comt-box form").on("submit", function(event) 
    {
        event.preventDefault();
        event.stopImmediatePropagation();
        let comment = jQuery(this).find('textarea').val();
        let post_id = jQuery(this).attr("data-post-id");

        if (!post_id) {
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: "/post/comment",
            data: $('#' + jQuery(this).attr("id")).serialize(),
            success: function(response) {
                if (response.status === true && response.code === 200) {
                    let parent = jQuery("#post-comment_form_" + post_id).parent(
                        "li");
                    let comment_HTML = response.data;
                    // $("#comment-box_" + post_id).prepend(comment_HTML);

                    if($("#comment-box_" + post_id).first().length > 0){

                        $(".comment-section_" + post_id).last().after(response.data);
                     
                    }
                    else{
                        $("#append_comment_" + post_id).append(comment_HTML);
                    }

                    // $("#append_comment_" + post_id).append(comment_HTML);
                    // $(comment_HTML).insertBefore("#post-comment_form_" + post_id);
                    $("#commentable_content_" + post_id).val("");
                    $("#comment_post_count_" + post_id).text(response.count);
                }
            },

            error: function(data) {
                data?.responseJSON?.error?.error ? $.notify(data.responseJSON.error
                    .error, "error") : ""
                data?.responseJSON?.message ? $.notify(data.responseJSON.message, "error") :
                    ""
                jQuery(this).find('textarea').val(' ');
            }
        });

    });

    $('#add-blog-post-form').submit(function(e) {

            e.preventDefault();
            let i = 1;
            $("#create-post-btn").attr('disabled', true);
            $("#create-post-btn").text("Posting");
            let formDataAddPost = new FormData($('#add-blog-post-form')[0]);
            console.log(...formDataAddPost);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                beforeSend: function() {
                    $('.add-post-progress-bar').html(
                        '<div class="progress"><div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div></div>'
                    );
                    setTimeout(function() {
                        $('.progress-bar').animate({
                            width: i + "%"
                        }, 100);
                    }, 10);
                    i = i + Math.floor(Math.random() * 100);
                },
                type: 'POST',
                url: "/create/post",
                data: formDataAddPost,
                cache: false,
                processData: false,
                contentType: false,
                success: (data) => {
                    console.log("success", data);
                    $('.progress-bar').addClass("bg-success")
                    $('.progress-bar').animate({
                        width: "100%",
                    }, 1);
                    $("#create-post-btn").attr('disabled', false);
                    $("#create-post-btn").text("Post");
                    setTimeout(function() {
                        window.location.reload();
                    }, 1000);
                },
                error: function(data) {
                    console.log("error", data);
                    $('.progress-bar').addClass("bg-danger")
                    $('.progress-bar').animate({
                        width: "100%"
                    }, 1);
                    $("#create-post-btn").attr('disabled', false);
                    $("#create-post-btn").text("Post");

                    data?.responseJSON?.error?.error ? $.notify(data.responseJSON.error
                        .error, "error") : ""
                    data?.responseJSON?.message ? $.notify(data.responseJSON.message, "error") :
                        ""
                    setTimeout(function() {
                        window.location.reload();
                    }, 1000);
                }
            });
            // this.submit();
        });


});



var post_id ='<?php echo e($post->id); ?>';
// alert(post_id);
$('.post-carousel').on('slide.bs.carousel', function (e) {

  // var slidingItemsAsIndex = $('.carousel-item').length - 1;
  var slidingItemsAsIndex = $(this).find('.carousel-item').length - 1;

  // If last item hide next arrow
  if($(e.relatedTarget).index() == slidingItemsAsIndex ){

      $(this).find('.carousel-control-next').hide();
  }
  else{
      $(this).find('.carousel-control-next').show();
  }

  // If first item hide prev arrow
  if($(e.relatedTarget).index() == 0){
      $(this).find('.carousel-control-prev').hide();
    }
  else{
      $(this).find('.carousel-control-prev').show();
    }

})
</script>










        <!-- Owl Carousel -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script> -->

<!-- Owl Carousel -->
<script>
    // Owl Carousel
    // $(".owl-carousel").owlCarousel();

    // $('.owl-carousel').owlCarousel({
    //     loop:false,
    //     margin:10,
    //     nav:true,
    //     responsive:{
    //         0:{
    //             items:1
    //         },
    //         600:{
    //             items:3
    //         },
    //         1000:{
    //             items:50
    //         }
    //     }
    // });
</script><?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/services/postSection.blade.php ENDPATH**/ ?>