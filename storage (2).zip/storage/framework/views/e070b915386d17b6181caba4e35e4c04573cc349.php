<?php
$userGallery = $service->user->imagesAsArray;
// $userGallery = $service->user
// ->imagesAsArray()
// ->get()
// ->toArray();
?>
<div class="lightbox lightbox-user-gallery">
    <!-- <div class="row">
        <?php $__currentLoopData = $userGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 my-1 gallery-img-item" id="gallery-id-<?php echo e($galleryImage->id); ?>">
            <div class="position-relative photos-section">
                <img src="<?php echo e($galleryImage->file_name); ?>" data-mdb-img="<?php echo e($galleryImage->file_name); ?>" alt="" class="w-100 shadow-1-strong rounded img-bg-overlay">
                <div class="box-shadow"></div>
            </div>
            <div class="likes gallery-reaction " data-gallery-image-id="<?php echo e($galleryImage->id); ?>" data-gallery-reaction-id="<?php echo e($galleryImage->likedPost()); ?>">
                <span class="gallery-like-heart heart float-left <?php echo e($galleryImage->userliked() ? 'active-heart' : ''); ?>"><i class="fas fa-heart"></i></span>
                <span class="liked_gallery_count" id="liked_gallery_count-<?php echo e($galleryImage->id); ?>"><?php echo e($galleryImage->likes->count()); ?></span>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->id == $service->user->id): ?>
                <span class="delete-gallery float-right" id="delete-gallery-<?php echo e($galleryImage->id); ?>" data-delete-post-id="<?php echo e($galleryImage->id); ?>" title="Delete"><i class="fas fa-trash"></i></span>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> -->

    <!-- Gallery images section -->
    <div id="gallery" class="gallery-section">
        <div class="w-100 bg-white">
            <?php $__currentLoopData = $userGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="position-relative photos-section">
                <img src="<?php echo e($galleryImage->file_name); ?>" class="img-responsive">
                <div class="box-shadow"></div>
                <div class="likes gallery-reaction " data-gallery-image-id="<?php echo e($galleryImage->id); ?>" data-gallery-reaction-id="<?php echo e($galleryImage->likedPost()); ?>">
                    <span class="gallery-like-heart heart float-left <?php echo e($galleryImage->userliked() ? 'active-heart' : ''); ?>"><i class="fas fa-heart"></i></span>
                    <span class="liked_gallery_count" id="liked_gallery_count-<?php echo e($galleryImage->id); ?>"><?php echo e($galleryImage->likes->count()); ?></span>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->id == $service->user->id): ?>
                    <span class="delete-gallery float-right" id="delete-gallery-<?php echo e($galleryImage->id); ?>" data-delete-post-id="<?php echo e($galleryImage->id); ?>" title="Delete"><i class="fas fa-trash"></i></span>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <img src="https://source.unsplash.com/1024x768?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/1366x768?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/1920x1080?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/640x360?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/320x640?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/1200x1600?female,portrait" class="card img-responsive">
            <img src="https://source.unsplash.com/800x600?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/600x800?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/400x600?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/600x400?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/1100x1600?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/1600x1100?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/992x768?female,portrait" class="img-responsive">
            <img src="https://source.unsplash.com/768x992?female,portrait" class="img-responsive"> -->
        </div>
    </div>

</div><?php /**PATH D:\Wamp-projects\umair-alexander\alexander\resources\views/services/galleryImages.blade.php ENDPATH**/ ?>